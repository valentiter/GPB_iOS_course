import Foundation

//Generate an array of random numbers (e.g. 200 numbers). Find the index of the first repeating number in the array. If all numbers are different - then -1.
//Example : [3, 4, 5, 6, 8, 78, 67, 4, 88] - 4, index 1

func generateRandomNumbers(size: Int) -> [Int] {
    guard size > 0 else {
        return [Int]()
    }
    
    let result = Array(repeating: 0, count: size)
    return result.map{ _ in Int.random(in: 0..<size)}
}

func findFirstDuplicate(_ array: [Int]) -> (number: Int, index: Int)? {
    var hashMap: [Int: Int] = [:]
    for (_, number) in array.enumerated() {
        hashMap[number, default: 0] += 1
        if hashMap[number, default: 0] > 1 {
            var previousLowestIndex: Int
            for (i, n) in array.enumerated() {
                if n == number {
                    previousLowestIndex = i
                    return (number, previousLowestIndex)
                }
            }
        }
    }
    return nil
}

let array = generateRandomNumbers(size: 20)
findFirstDuplicate(array)
