import Foundation


//Generating arrays

let size = 25  // setting default size of arrays & dict

func generateRandomNumbers(size: Int) -> [Int] {
    guard size > 0 else {
        return [Int]()
    }
    
    let result = Array(repeating: 0, count: size)
    return result.map{ _ in Int.random(in: 0..<size)}
}


func generateRandomSymbols(size: Int) -> [Character] {
    guard size > 0 else {
        return [Character]()
    }
    
    let letters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    let result = (0..<size).map{ _ in letters.randomElement()! }
    return result
}



// 1) There is an arbitrary array of numbers, to find the maximum and minimum numbers and swap them is needed.

extension Collection where Element: Comparable {
    func IndexOfMax() -> Index? {
        zip(indices, self).max(by: { $0.1 < $1.1 })?.0
    }
    func IndexOfMin() -> Index? {
        zip(indices, self).min(by: { $0.1 < $1.1 })?.0
    }
}

func swapMinMax(numArray: inout [Int]) -> () {
    guard let indexOfMax = numArray.IndexOfMax() else { return () }
    guard let indexOfMin = numArray.IndexOfMin() else { return () }
    return numArray.swapAt(indexOfMin, indexOfMax)
}

var myArray = generateRandomNumbers(size: size)
swapMinMax(numArray: &myArray)



// 2) There are two arrays of symbols - collect the resulting set of symbols that are repeated in the 2 arrays.

func findRepeats(charArray1: [Character], charArray2: [Character]) -> [Character] {
    let repeats = charArray1.filter{charArray2.contains($0)}
    return repeats
}

let charArray1 = generateRandomSymbols(size: size)
let charArray2 = generateRandomSymbols(size: size)

findRepeats(charArray1: charArray1, charArray2: charArray2)



// 3) Create a dictionary with the ratio of user name (key) to password (value), get from the dictionary all the names whose passwords are longer than 10 characters

//generating a dictionary

var users = [String: String]()


for _ in 0...size {
    let login = String(generateRandomSymbols(size: Int.random(in: 0..<6)))
    let password = String(generateRandomSymbols(size: Int.random(in: 0..<16)))
    users[login] = password
}


func findLongPassswords(users: Dictionary<String, String>) -> [String] {
    let result = users.filter({ $0.value.count > 10})
    return Array(result.keys)
}

findLongPassswords(users: users)


